{{- template "base_script" . }}
